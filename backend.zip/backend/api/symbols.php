<?php
require_once '../auth.php';
require_once '../utils/response.php';
requireLogin();

$binance_url = "https://fapi.binance.com/fapi/v1/exchangeInfo";
$data = file_get_contents($binance_url);
sendResponse(json_decode($data,true));
?>

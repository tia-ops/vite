<?php
require_once '../auth.php';
require_once '../utils/response.php';
requireLogin();

$symbol = $_GET['symbol'] ?? '';
if (!$symbol) sendResponse(['error'=>'symbol wajib diisi'],400);
if (!preg_match('/^[A-Z0-9]{5,20}$/', $symbol)) sendResponse(['error'=>'symbol tidak valid'],400);

$binance_url = "https://fapi.binance.com/fapi/v1/ticker/price?symbol=$symbol";
$data = file_get_contents($binance_url);
sendResponse(json_decode($data,true));
?>
